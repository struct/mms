#include <stdio.h>
#include <stdlib.h>
#include <memory>

using namespace std;

class Base {
	public:
		Base() {
			p = (char *) malloc(1024);
		}

		~Base() {
			free(p);
		}

	private:
		char *p;
};

int main() {
	Base *b = new Base();
	unique_ptr<Base> p1(b);
	unique_ptr<Base> p2(b);
	return 0;
}
