#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <iostream>

using namespace std;

class Base {
  public:
    Base() { v = 1; }

    ~Base() { v = 0; }

    Base(const Base& b) {
        v = b.v;
    }

    Base operator=(const Base& b) {
        v = b.v;
        return *this;
    }

    int v;
};

Base f(Base b) {
    return b;
}

Base *ff(Base *b) {
    return b;
}

int main(int argc, char *argv[]) {

    // Triggers the move constructor due
    // to the temporary rvalue object
	Base *y = new Base();
    delete y;

	return 0;
}
