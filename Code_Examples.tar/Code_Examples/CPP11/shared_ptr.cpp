#include <stdio.h>
#include <stdlib.h>
#include <memory>

using namespace std;

class Base {
	public:
		Base() {
			p = (char *) malloc(1024);
		}

		~Base() {
			free(p);
		}

	private:
		char *p;
};

int main() {
	Base *b = new Base();
	shared_ptr<Base> p1(b);
	shared_ptr<Base> p2(b);
	printf("%lu\n", p1.use_count());
	printf("%lu\n", p2.use_count());
	auto sp = make_shared<Base>();
	return 0;
}
