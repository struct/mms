#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <utility>

using namespace std;

class RefCountedObj {
	public:
		RefCountedObj(void *p, size_t s)
			: size(s), ptr(p) {
				refcount = 1;
		}

		~RefCountedObj () { }

		void incRef() { refcount++; }
		void decRef() { refcount--; }

		int reallocPtr(size_t sz) {
			void *tmp;
			tmp = realloc(ptr, sz);

			incRef();

			if(tmp == NULL) {
				return -1;
			} else {
				ptr = tmp;
			}

			return 0;
		}

		int32_t refcount;
		size_t size;
		void *ptr;
};

class AbstractClass {
	public:
		AbstractClass(size_t sz) {
			uint8_t *o = (uint8_t *) malloc(sz);
			rco = createRefCountedObj((void *) o, sz);
		}

		AbstractClass(uint8_t *p, size_t sz) {
			rco = createRefCountedObj((void *) p, sz);
		}

		AbstractClass(AbstractClass *ac) {
			rco = ac->rco;
			rco->incRef();
		}

		AbstractClass(const AbstractClass &ac) {
			rco = ac.rco;
			rco->incRef();
		}

		AbstractClass(const AbstractClass&& ac) {
			rco = ac.rco;
			rco->incRef();
		}

		AbstractClass operator=(AbstractClass *r) {
			maybeDeleteRefObj();
			rco = r->rco;
			return *this;
		}

		AbstractClass operator=(const AbstractClass&& r) {
			maybeDeleteRefObj();
			rco = r.rco;
			rco->incRef();
			return *this;
		}

		AbstractClass operator=(const AbstractClass &r) {
			maybeDeleteRefObj();
			rco = r.rco;
			rco->incRef();
			return *this;
		}

		~AbstractClass() {
			maybeDeleteRefObj();
		}

		void debug(const char *s) {
			printf("DEBUG: (%s) this = %p rco = %p rco->ptr = %p rco->size = %zu rco->refcount = %x\n", s, this, rco, rco->ptr, rco->size, rco->refcount);
		}

		int resize(size_t sz) {
			return rco->reallocPtr(sz);
		}

	private:
		RefCountedObj *createRefCountedObj(void *t, size_t s) {
			RefCountedObj *o = new RefCountedObj(t, s);
			return o;
		}

		void maybeDeleteRefObj() {
			rco->decRef();
			if(rco->refcount <= 0) {
				free(rco->ptr);
				delete rco;
			}
		}

		RefCountedObj *rco;
};

int main(int argc, char *argv[]) {

	AbstractClass *a = new AbstractClass(1024);
	AbstractClass d = a;
 	AbstractClass *b = new AbstractClass(a);

	uint8_t *p = (uint8_t *) malloc(1024);

	AbstractClass *c = NULL;

	if(p) {
		c = new AbstractClass(p, 1024);
	}

	*b = c;

	if(argv[1] != NULL) {
		b->resize(atol(argv[1]));
	}

	a->debug("a");
	b->debug("b");
	c->debug("c");
	d.debug("d");

	AbstractClass e(std::move(d));

	delete a;
	delete b;
	delete c;

	return 0;
}
