g++ -o ipc_recv ipc_recv.cpp libvalidateblob.c -O2 -DLOCAL_SOCKET -fno-stack-protector -Wall -m32
