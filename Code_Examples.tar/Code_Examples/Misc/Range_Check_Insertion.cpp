// Microsoft Range Check Insertion
// Compile this code with MSVC 2010 or 2012
// Open in IDA and view main(), look for the
// following code:

// .text:00401037                 cmp     [ebp+var_108], 100h ; Compare size of array to value we are indexing
// .text:00401041                 jnb     short loc_401045 -------------------------------	; value is out of range, throw rangecheckfailure
// .text:00401043                 jmp     short loc_40104A ---------------------------   |	; value is within range, proceed
// .text:00401045 ; --------------------------------------							 |   |
// .text:00401045																	 |   |
// .text:00401045 loc_401045:                             ; CODE XREF: sub_401000+41 | <--
// .text:00401045                 call    ___report_rangecheckfailure				 |
// .text:0040104A																 	 |
// .text:0040104A loc_40104A:                             ; CODE XREF: sub_401000+43 |
// .text:0040104A                 mov     edx, [ebp+var_108]				<---------		; load address of the array into edx
// .text:00401050                 mov     [ebp+edx+var_104], 0 ; Write the NULL byte within bounds

#include <stdio.h>
#include <string.h>

int main() {
	char first_buf[256];
	memset(first_buf, 0x0, sizeof(first_buf));
	first_buf[sizeof(first_buf)] = '\0';
	return 0;
}