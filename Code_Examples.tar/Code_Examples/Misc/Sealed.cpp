// Play around with adding the sealed keyword
// and disassembling the binary
#include <iostream>

using namespace std;

class Base {
  public:
    virtual void Virt() {
        cout << "Base Virt";
    }
};

class Derived : public Base {
  public:
    virtual void Virt() sealed {
        cout << "Derived Virt!";
    }
};

int main() {
    Derived *der = new Derived();
    der->Virt();
    delete der;
    return 0;
}

