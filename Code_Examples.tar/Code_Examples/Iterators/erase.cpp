#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <vector>

using namespace std;

// Overloaded << operator for ostream
// Takes an int vector and prints out each member
ostream &operator << (ostream &os, const vector<int> &coll) {
	os << "@ " << &coll[0] << " | " << coll.size() << " ";
	vector<int>::const_iterator start = coll.begin();
	for(int i=0; i<coll.size(); i++, start++) {
		os << "[" << i << "] " << hex << *start << dec << " ";
	}

	return os;
}

int main(int argc, char *argv[]) {

	if(argv[1] == NULL) {
		printf("Please supply two integers\n");
		return 0;
	}

	// Declare three vectors holding int's
	vector<int> bec, vec, dec;

	// Read in two numeric arguments from command line
	// (Example: 100 5)
	// (Example: 20 100)
	int b = atol(argv[1]);
	int c = atol(argv[2]);

	// Allocate a large chunk of memory
	//char *m = (char *) malloc(4096);
	// Mark the chunk of memory with 'a' characters
	//memset(m, 0x61, 4096);
	// Free the chunk (our vectors will likely be mapped at the same address
	//free(m);

	// Fill up each vector with easily recognizable constant values
	bec.assign(10, 0x42424242);
	vec.assign(10, 0x43434343);
	dec.assign(10, 0x44444444);

	// Print the location of each vector base in memory
	cout << "bec " << &bec[0] << endl << "vec " << &vec[0] << endl << "dec " << &dec[0] << endl;

	// Print out the contents of each vector
	cout << endl << "bec " << bec << endl;
	cout << endl << "vec " << vec << endl;
	cout << endl << "dec " << dec << endl;

	// Call the erase method on vec (the vector allocated in between bec and dec)
	// using our command line numeric arguments to influence the start/end iterators
	vec.erase(vec.begin()+b, vec.begin()+c);

	cout << endl << "vec.erase called!" << endl;

	// Print out the contents of each vector
	cout << endl << "bec " << bec << endl;
	cout << endl << "vec " << vec << endl;
	cout << endl << "dec " << dec << endl;

	return 0;
}
