#include <stdio.h>

class Base {
  public:
    virtual void foo() { printf("Base foo\n"); }
};

class Derived : public Base {
  public:
    Derived() { }
    virtual ~Derived() { }
    void foo() { printf("derived foo\n"); }
};

int main() {
    Derived *f = new Derived();
    Base *v = dynamic_cast<Base *>(f);
    v->foo();
    delete f;
}
