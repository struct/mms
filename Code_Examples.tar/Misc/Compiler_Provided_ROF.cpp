#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

class RefCountedObj {
	public:
		RefCountedObj(void *p, size_t s)
			: size(s), ptr(p) {
				refcount = 1;
		}

		~RefCountedObj () { }

		void incRef() { refcount++; }
		void decRef() { refcount--; }

		int32_t refcount;
		size_t size;
		void *ptr;
};

// The AbstractClass owns a RefCount class
class AbstractClass {
	public:
		AbstractClass(size_t sz) {
			uint8_t *o = (uint8_t *) malloc(sz);
			rco = createRefCountedObj((void *) o, sz);
		}

		AbstractClass(uint8_t *p, size_t sz) {
			rco = createRefCountedObj((void *) p, sz);
		}

		~AbstractClass() {
			maybeDeleteRefObj();
		}

		void debug(const char *s) {
			printf("DEBUG: (%s) this = %p rco = %p rco->ptr = %p rco->size = %zu rco->refcount = %x\n", s, this, rco, rco->ptr, rco->size, rco->refcount);
		}

	private:
		RefCountedObj *createRefCountedObj(void *t, size_t s) {
			RefCountedObj *o = new RefCountedObj(t, s);
			return o;
		}

		void maybeDeleteRefObj() {
			printf("DEBUG: this=%p Decrementing refcount for %p\n", this, rco);
			rco->decRef();
			if(rco->refcount <= 0) {
				printf("DEBUG: this=%p Freeing %p %p\n", this, rco, rco->ptr);
				free(rco->ptr);
				delete rco;
			}
		}

		RefCountedObj *rco;
};

int main(int argc, char *argv[]) {
	AbstractClass a(1);

	// (1) Where is this copy constructor implemented?
	AbstractClass *b = new AbstractClass(a);
	AbstractClass j = a;

	a.debug("a");
	b->debug("b");
	//j.debug("j");

	delete b;

	// (2) What happens when 'a' and 'j' go out of scope?
	return 0;
}
