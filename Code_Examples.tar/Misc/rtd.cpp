// return type deduction
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//using namespace std;

typedef struct A {
	int a;
	char *b;
} _A;

typedef struct B {
	char *b;
} _B;

auto foo() {
	A *a = (A *) malloc(sizeof(A));
	a->a = 0x41424344;
	return a;
}

int main(int argc, char *argv[]) {
	B *b = reinterpret_cast<B *>(foo());
	printf("%p\n", b->b);
}
