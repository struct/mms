// A stripped down version of goto fail
// The return values are different but
// the bad logic is the same

#include <stdio.h>
#include <stdlib.h>

int hash_compare(int i, int *flag) {
	if(i == 1234567890) {
		printf("actual success\n");
		*flag = 1;
		return 0;
	}

	*flag = 0;
	// return error on no match
	return -1;
}

int has_value(int a) {
	if(a != 0) {
		return 0;
	}

	// return error on 0
	return -1;
}

int check_hash(int a) {
	int error = 0;
	int flag = 0;

	if((error = has_value(a)) != 0)
		goto fail;
		goto fail;

	if((error = hash_compare(a, &flag)) != 0)
		goto fail;

	if(flag == 1) {
		return 0;
	}

	// Detect errors
fail:
	return error;
}

int main(int argc, char *argv[]) {
	if(check_hash(atoi(argv[1])) == 0) {
		printf("Success!\n");
	} else {
		printf("Hilarious fail!\n");
	}
}