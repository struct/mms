#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
	FILE *fd;

	if((fd = fopen("conf.txt", "r")) == NULL) {
		printf("Could not open your file!\n");
		return -1;
	}

	unsigned int filelines = 0;
	char buf[128];
	char tmp[128];
	char *index;
	char *ptr1;
	char *ptr2;

	fseek(fd, 0, SEEK_SET);

	while((fgets(buf, sizeof(buf)-1, fd)) != NULL) {
        index = buf;

	    if((index != NULL) && (*index != '#') && (*index != 0x0a) && (*index != ';')) {
	        if((strncmp(buf, "remoteHost", 10)) == 0) {
    	        ptr1 = strchr(buf, '{');

	            if(ptr1 == NULL)
    	           continue;

        	    ptr1++;
            	ptr2 = strchr(buf, '}');

	            if(ptr2 == NULL)
    	            continue;

        	    if((ptr2 - ptr1) > (int)(128 - strlen("remoteHost")))
            	    continue;

				memcpy(tmp, ptr1, (ptr2-ptr1)-1);
				printf("remoteHost {%s}\n", tmp);
			}

	        if((strncmp(buf, "errorString", 11)) == 0) {
    	        ptr1 = strchr(buf, '{');

	            if(ptr1 == NULL)
    	           continue;

        	    ptr1++;
            	ptr2 = strchr(buf, '}');

	            if(ptr2 == NULL)
    	            continue;

        	    if((ptr2 - ptr1) > (128 - strlen("errorString")))
            	    continue;

				memcpy(tmp, ptr1, (*ptr2-*ptr1)-1);
				printf("errorString {%s}\n", tmp);
			}
		}

		memset(buf, 0x0, sizeof(buf));
	}

	return 0;
}
