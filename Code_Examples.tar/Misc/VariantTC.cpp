// Variant Type Confusion Example
// To compile this code open your
// Visual Studio 200X command prompt:
// cl VariantTC.cpp "oleaut32.lib"

#include <Windows.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

int variantRecv(VARIANT *v) {
	cout << hex << v->lVal << "\n";
	return 0;
}

int main(int argc, char* argv[]) {
	if(argc < 2) {
		cout << "Please supply a string!\n";
		return -1;
	}

	VARIANT v;
	VariantInit(&v);

	// Variant contains a BSTR type
	v.vt = VT_BSTR;
	v.bstrVal = BSTR(argv[1]);

	// Send the Variant to a remote COM component
	variantRecv(&v);

	return 0;
}
